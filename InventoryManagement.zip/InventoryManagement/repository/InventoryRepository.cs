﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using System.Data.Entity;

namespace InventoryManagement.repository
{
    public class InventoryRepository : IInventory
    {
        private InventoryManagementEntitiesNew _DbContext;
        public InventoryRepository(InventoryManagementEntitiesNew _ObjDbContext)
        {
            this._DbContext= _ObjDbContext;
        }

        void IInventory.InsertInventory(InventoryMaster _Inventory)
        {
            _DbContext.InventoryMasters.Add(_Inventory);
            _DbContext.SaveChanges();
        }

        IEnumerable<InventoryMaster> IInventory.GetInventory()
        {
            return _DbContext.InventoryMasters.ToList();
        }
        InventoryMaster IInventory.GetInventoryByID(int InventoryId)
        {
            return _DbContext.InventoryMasters.Find(InventoryId);
        }

        void IInventory.UpdateInventory(InventoryMaster Inventory)
        {
            _DbContext.Entry(Inventory).State = EntityState.Modified;

            _DbContext.SaveChanges();
        }

        void IInventory.DeleteInventory(int InventoryId)    
        {
            InventoryMaster inventory = _DbContext.InventoryMasters.Find(InventoryId);

            _DbContext.InventoryMasters.Remove(inventory);

            _DbContext.SaveChanges();
        }

        public bool InventoryMasterExists(int id)
        {
                return _DbContext.InventoryMasters.Count(e => e.InventoryId == id) > 0;
        }
    }
}