﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.repository
{
    interface IInventory
    {
        void InsertInventory(Models.InventoryMaster _Inventory); // C

        IEnumerable<Models.InventoryMaster> GetInventory(); // R

        Models.InventoryMaster GetInventoryByID(int InventoryId); // R

        void UpdateInventory(Models.InventoryMaster Inventory); //U

        void DeleteInventory(int InventoryId); //D

        bool InventoryMasterExists(int id);



    }
}
