﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using InventoryManagement.Models;

using System.Threading.Tasks;

namespace InventoryManagement.Controllers
{

    // Applying Exception Filter
    [CustomExceptionFilter]
    public class InventoryMastersController : ApiController
    {
        
        InventoryManagementEntitiesNew _db = new InventoryManagementEntitiesNew();

        // GET: api/InventoryMasters

        public async Task<IHttpActionResult> GetInventoryMasters()
        {
            var data = await _db.InventoryMasters.ToListAsync();
            return Ok(data);
        }
       
        // GET: api/InventoryMasters/5

        public async Task< IHttpActionResult> GetInventoryMaster(int id)
        {
            var inventoryMaster = await _db.InventoryMasters.Where(f => f.InventoryId== id).FirstOrDefaultAsync();
            if (inventoryMaster == null)
            {
                return NotFound();
            }

            return Ok(inventoryMaster);
        }

        
        // PUT: api/InventoryMasters/5
        public async Task<IHttpActionResult> UpdateInventoryMaster(int id, InventoryMaster inventoryMaster)
        {
            var record = await _db.InventoryMasters.Where(f => f.InventoryId == id).FirstOrDefaultAsync();
            if (record != null)
            {
                record.Name = inventoryMaster.Name;
                record.Description= inventoryMaster.Description;
                record.Price = inventoryMaster.Price;
                await _db.SaveChangesAsync();
                return Ok();
            }
            return NotFound();
        }

        

        // POST: api/InventoryMasters
        public async Task<IHttpActionResult> AddInventoryMaster(InventoryMaster inventoryMaster)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _db.InventoryMasters.Add(inventoryMaster);
            await _db.SaveChangesAsync();
            return CreatedAtRoute("DefaultApi", new { id = inventoryMaster.InventoryId }, inventoryMaster);
        }
        
        // DELETE: api/InventoryMasters/5

        public async Task<IHttpActionResult> DeleteInventoryMaster(int id)
        {
            var record = await _db.InventoryMasters.Where(f => f.InventoryId== id).FirstOrDefaultAsync();
            if (record != null)
            {
                _db.InventoryMasters.Remove(record);
                await _db.SaveChangesAsync();
                return Ok();
            }
            return NotFound();
        }
        
    }
}